﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
using Simple_Ajax_PagedList_And_Search_Mvc5.Models;

namespace Simple_Ajax_PagedList_And_Search_Mvc5.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index(string searchString, string sortOption, int page = 1)
        {
            int pageSize = 10;

            //List<Category> dept = new List<Category>();
            //dept.Add(new Category(1, "Food"));
            //dept.Add(new Category(2, "Furniture"));
            //dept.Add(new Category(3, "Grocery"));
            //dept.Add(new Category(4, "Fashion"));
            //ViewBag.dept = new SelectList(dept, "Name", "Name");

            List<Product> lstProduct = new List<Product>();
            IEnumerable<Product> lstEnProduct = new List<Product>();


            for (int i = 0; i < 200; i++)
            {
                DateTime dateTime = new DateTime();
                dateTime = DateTime.Now.AddDays(-300);
                Product emp = new Product();
                emp.Id = i;
                emp.Name = i.ToString() + " Product";
                if (i % 5 == 0)
                {
                    emp.Category = "Food";
                }
                else if (i % 3 == 0)
                {
                    emp.Category = "Furniture";
                }
                else if (i % 2 == 0)
                {
                    emp.Category = "Grocery";
                }
                else
                {
                    emp.Category = "Fashion";
                }
                //emp.Category = i.ToString() + " Category ";
                emp.Price = i + 100;
                emp.Qty = i + 10;
                emp.PurchaseDate = dateTime.AddDays(i);
                lstProduct.Add(emp);
            }

            lstEnProduct = lstProduct;

            if (!String.IsNullOrEmpty(searchString))
            {
                lstEnProduct = lstProduct.Where(p => p.Category.ToLower().Contains(searchString.ToLower()));
            }
            switch (sortOption)
            {
                case "name_acs":
                    lstEnProduct = lstEnProduct.OrderBy(p => p.Name);
                    break;
                case "name_desc":
                    lstEnProduct = lstEnProduct.OrderByDescending(p => p.Name);
                    break;
                case "price_acs":
                    lstEnProduct = lstEnProduct.OrderBy(p => p.Price);
                    break;
                case "price_desc":
                    lstEnProduct = lstEnProduct.OrderByDescending(p => p.Price);
                    break;
                case "qty_acs":
                    lstEnProduct = lstEnProduct.OrderBy(p => p.Qty);
                    break;
                case "qty_desc":
                    lstEnProduct = lstEnProduct.OrderByDescending(p => p.Qty);
                    break;
                default:
                    lstEnProduct = lstEnProduct.OrderBy(p => p.Id);
                    break;

            }


            return Request.IsAjaxRequest()
                ? (ActionResult)PartialView("ProductList", lstEnProduct.ToPagedList(page, pageSize))
                : View(lstEnProduct.ToPagedList(page, pageSize));
        }


        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}