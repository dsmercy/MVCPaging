﻿using System;

namespace Simple_Ajax_PagedList_And_Search_Mvc5.Models
{
    public class Product
    {
        public  int Id { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public float  Price { get; set; }
        public int Qty { get; set; }
        public DateTime PurchaseDate { get; set; }
    }
    public class Category
    {
        public Category(int Id, string Name)
        {
            this.Id = Id;
            this.Name = Name;
        }
        public int Id { get; set; }
        public string Name { get; set; }
    }
}