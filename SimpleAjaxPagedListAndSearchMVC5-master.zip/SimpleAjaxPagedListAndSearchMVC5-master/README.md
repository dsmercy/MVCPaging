# SimpleAjaxPagedListAndSearchMVC5


This is MVC5 application demonstrate how to create pagination and search functionality in Ajax way.

## Demo site:

[http://ajaxpagination.azurewebsites.net/](http://ajaxpagination.azurewebsites.net/)


![](https://raw.github.com/ungleng/SimpleAjaxPagedListAndSearchMVC5/master/screenshot/screenshot.png)
